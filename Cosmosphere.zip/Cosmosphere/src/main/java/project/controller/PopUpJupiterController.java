package project.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import project.cosmosphere.App;

public class PopUpJupiterController implements Initializable {
    @FXML
    private BorderPane PopUpJupiter;

    @FXML
    public void fecharPopUpJupiter() throws IOException {
        Stage stage = (Stage) PopUpJupiter.getScene().getWindow();
        stage.close();
    }
    @FXML
    public void AbrirCuriosidadesJupiter() throws IOException {
        URL url = App.class.getResource("PopUpJupiter.fxml");
        FXMLLoader fxml = new FXMLLoader(url);
        Parent raiz = fxml.load();
        
        Stage stage = (Stage) PopUpJupiter.getScene().getWindow();
        stage.setScene(new Scene(raiz));
        stage.setTitle("Cosmosphere - curiosidades Jupiter");
        stage.show();
    
    }  
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
